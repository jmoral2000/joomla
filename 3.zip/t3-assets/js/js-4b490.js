

/*===============================
/templates/shopy/js/script.js
================================================================================*/;
jQuery(document).ready(function($){$(window).load(function(){$('#preloader').fadeOut('slow',function(){$(this).remove();});});});