<?php
/**
 * @package   T3 Blank
 * @copyright Copyright (C) 2005 - 2012 Open Source Matters, Inc. All rights reserved.
 * @license   GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;
?>

<?php if ($this->countModules('shipping_wrap')) : ?>
	<!-- t3-slider -->
	<div class="wrap t3-shipping_wrap">
		<div class="col-md-12 col-xs-12 col-sm-12 ship-position">
			<jdoc:include type="modules" name="<?php $this->_p('shipping_wrap') ?>" />
		</div>
	</div>
	<!-- //t3-slider  -->
<?php endif ?>
