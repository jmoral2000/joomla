#
#<?php die('Forbidden.'); ?>
#Date: 2020-04-05 09:33:30 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-04-05T09:33:30+00:00	INFO 127.0.0.1	update	Update started by user Super User (427). Old version is 3.8.0.
2020-04-05T09:33:34+00:00	INFO 127.0.0.1	update	Downloading update file from https://s3-us-west-2.amazonaws.com/joomla-official-downloads/joomladownloads/joomla3/Joomla_3.9.16-Stable-Update_Package.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIZ6S3Q3YQHG57ZRA%2F20200405%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20200405T093320Z&X-Amz-Expires=60&X-Amz-SignedHeaders=host&X-Amz-Signature=4c5fcd4425ea1c53f48c4072a1aa14d137a0dd4cb1c359ab79f3d0ca0f468328.
2020-04-05T09:33:59+00:00	INFO 127.0.0.1	update	File Joomla_3.9.16-Stable-Update_Package.zip downloaded.
2020-04-05T10:00:12+00:00	INFO 127.0.0.1	update	Actualización inciciadoa por el usuario Super User (427). La versión antigua es la 3.8.0.
2020-04-05T10:00:15+00:00	INFO 127.0.0.1	update	El archivoe Joomla_3.9.16-Stable-Update_Package.zip se ha descargado.
