#
#<?php die('Forbidden.'); ?>
#Date: 2020-04-05 09:17:55 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-04-05T09:17:55+00:00	INFO 127.0.0.1	update	Update started by user Super User (427). Old version is 3.8.0.
2020-04-05T09:17:58+00:00	INFO 127.0.0.1	update	Downloading update file from https://s3-us-west-2.amazonaws.com/joomla-official-downloads/joomladownloads/joomla3/Joomla_3.9.16-Stable-Update_Package.zip?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAIZ6S3Q3YQHG57ZRA%2F20200405%2Fus-west-2%2Fs3%2Faws4_request&X-Amz-Date=20200405T091744Z&X-Amz-Expires=60&X-Amz-SignedHeaders=host&X-Amz-Signature=3f8b40e5256292a033f3b3b7725f88096fd66346d1b45b2f7488276ea7cfa33f.
2020-04-05T09:18:01+00:00	INFO 127.0.0.1	update	File Joomla_3.9.16-Stable-Update_Package.zip downloaded.
2020-04-05T09:18:12+00:00	INFO 127.0.0.1	update	Starting installation of new version.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Finalising installation.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.2-2017-10-14. Query text: ALTER TABLE `#__content` ADD INDEX `idx_alias` (`alias`(191));.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.4-2018-01-16. Query text: ALTER TABLE `#__user_keys` DROP INDEX `series_2`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.4-2018-01-16. Query text: ALTER TABLE `#__user_keys` DROP INDEX `series_3`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.6-2018-02-14. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.6-2018-02-14. Query text: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.8-2018-05-18. Query text: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.8.9-2018-06-19. Query text: UPDATE `#__extensions` SET `enabled` = '1' WHERE `name` = 'mod_sampledata';.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-02. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-02. Query text: CREATE TABLE IF NOT EXISTS `#__privacy_requests` (   `id` int(10) unsigned NOT N.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-03. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: CREATE TABLE IF NOT EXISTS `#__action_logs` (   `id` int(10) unsigned NOT NULL A.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: CREATE TABLE IF NOT EXISTS `#__action_logs_extensions` (   `id` int(10) unsigned.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: INSERT INTO `#__action_logs_extensions` (`id`, `extension`) VALUES (1, 'com_bann.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: CREATE TABLE IF NOT EXISTS `#__action_log_config` (   `id` int(10) unsigned NOT .
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-05. Query text: INSERT INTO `#__action_log_config` (`id`, `type_title`, `type_alias`, `id_holder.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-19. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-20. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-24. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-24. Query text: CREATE TABLE IF NOT EXISTS `#__privacy_consents` (   `id` int(10) unsigned NOT N.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-05-27. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-02. Query text: ALTER TABLE `#__content` ADD COLUMN `note` VARCHAR(255) NOT NULL DEFAULT '';.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-02. Query text: UPDATE `#__content_types` SET `field_mappings` =  '{"common":{"core_content_item.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-12. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-13. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-14. Query text: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-06-17. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-07-09. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-07-10. Query text: INSERT INTO `#__action_log_config` (`id`, `type_title`, `type_alias`, `id_holder.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-07-11. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-08-12. Query text: ALTER TABLE `#__privacy_consents` ADD COLUMN `state` INT(10) NOT NULL DEFAULT 1 .
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-08-28. Query text: ALTER TABLE `#__session` MODIFY `session_id` varbinary(192) NOT NULL;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-08-28. Query text: ALTER TABLE `#__session` MODIFY `guest` tinyint(3) unsigned DEFAULT 1;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-08-28. Query text: ALTER TABLE `#__session` MODIFY `time` int(11) NOT NULL DEFAULT 0;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-08-29. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-09-04. Query text: CREATE TABLE IF NOT EXISTS `#__action_logs_users` (   `user_id` int(11) UNSIGNED.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-15. Query text: ALTER TABLE `#__action_logs` ADD INDEX `idx_user_id` (`user_id`);.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-15. Query text: ALTER TABLE `#__action_logs` ADD INDEX `idx_user_id_logdate` (`user_id`, `log_da.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-15. Query text: ALTER TABLE `#__action_logs` ADD INDEX `idx_user_id_extension` (`user_id`, `exte.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-15. Query text: ALTER TABLE `#__action_logs` ADD INDEX `idx_extension_item_id` (`extension`, `it.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-20. Query text: ALTER TABLE `#__privacy_requests` DROP INDEX `idx_checkout`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-20. Query text: ALTER TABLE `#__privacy_requests` DROP COLUMN `checked_out`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-20. Query text: ALTER TABLE `#__privacy_requests` DROP COLUMN `checked_out_time`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.0-2018-10-21. Query text: INSERT INTO `#__extensions` (`extension_id`, `package_id`, `name`, `type`, `elem.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.3-2019-01-12. Query text: UPDATE `#__extensions`  SET `params` = REPLACE(`params`, '"com_categories",', '".
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.3-2019-01-12. Query text: INSERT INTO `#__action_logs_extensions` (`extension`) VALUES ('com_checkin');.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.3-2019-02-07. Query text: INSERT INTO `#__postinstall_messages` (`extension_id`, `title_key`, `description.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.7-2019-04-23. Query text: ALTER TABLE `#__session` ADD INDEX `client_id_guest` (`client_id`, `guest`);.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.7-2019-04-26. Query text: UPDATE `#__content_types` SET `content_history_options` = REPLACE(`content_histo.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.8-2019-06-11. Query text: UPDATE #__users SET params = REPLACE(params, '",,"', '","');.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.8-2019-06-15. Query text: ALTER TABLE `#__template_styles` DROP INDEX `idx_home`;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.8-2019-06-15. Query text: ALTER TABLE `#__template_styles` ADD INDEX `idx_client_id` (`client_id`);.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.8-2019-06-15. Query text: ALTER TABLE `#__template_styles` ADD INDEX `idx_client_id_home` (`client_id`, `h.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.10-2019-07-09. Query text: ALTER TABLE `#__template_styles` MODIFY `home` char(7) NOT NULL DEFAULT '0';.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__categories` MODIFY `description` mediumtext;.
2020-04-05T09:18:16+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__categories` MODIFY `params` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__fields` MODIFY `default_value` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__fields_values` MODIFY `value` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__finder_links` MODIFY `description` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__modules` MODIFY `content` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_body` mediumtext;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_params` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_images` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_urls` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_metakey` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-02-15. Query text: ALTER TABLE `#__ucm_content` MODIFY `core_metadesc` text;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-03-04. Query text: ALTER TABLE `#__users` DROP INDEX `username`;.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Ran query from file 3.9.16-2020-03-04. Query text: ALTER TABLE `#__users` ADD UNIQUE INDEX `idx_username` (`username`);.
2020-04-05T09:18:17+00:00	INFO 127.0.0.1	update	Deleting removed files and folders.
2020-04-05T09:18:18+00:00	INFO 127.0.0.1	update	Cleaning up after installation.
2020-04-05T09:18:18+00:00	INFO 127.0.0.1	update	Update to version 3.9.16 is complete.
