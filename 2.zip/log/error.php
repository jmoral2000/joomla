#
#<?php die('Forbidden.'); ?>
#Date: 2020-04-18 14:20:52 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2020-04-18T14:20:52+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2020-04-18T14:30:27+00:00	INFO 127.0.0.1	gmailfailure	Failed to authenticate: Access Denied
2020-04-24T13:01:50+00:00	INFO 127.0.0.1	gmailfailure	Failed to authenticate: Access Denied
